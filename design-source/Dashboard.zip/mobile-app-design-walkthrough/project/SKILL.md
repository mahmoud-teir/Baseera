---
name: baseerah-design
description: Use this skill to generate well-branded interfaces and assets for Baseerah (بصيرة), an Arabic RTL Islamic-learning app, for production or throwaway prototypes. Contains design guidelines, colors, type, and tokens.
user-invocable: true
---

Read the README.md within this skill, and explore the other files.
If creating visual artifacts (slides, mocks, prototypes), copy assets out and create static HTML files. If working on production code, copy tokens and read the rules to become an expert in this brand. Never invent religious text, sources, scholars or titles: leave verified-source slots empty with a dashed placeholder.
If invoked without guidance, ask what to build, ask a few questions, and act as an expert designer.
