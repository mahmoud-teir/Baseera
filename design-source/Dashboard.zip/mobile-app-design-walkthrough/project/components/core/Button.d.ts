export interface ButtonProps{variant?:'primary'|'secondary';disabled?:boolean;full?:boolean;onClick?:()=>void;children?:React.ReactNode}
export function Button(props:ButtonProps):JSX.Element;