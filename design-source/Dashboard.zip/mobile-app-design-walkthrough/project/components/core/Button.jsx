import React from 'react';
export function Button({variant='primary',children,disabled=false,onClick,full=false}){
  const v=disabled?{background:'var(--bs-lock)',color:'#9A9486',border:'0'}:variant==='secondary'?{background:'transparent',color:'var(--bs-green)',border:'1.5px solid var(--action)'}:{background:'var(--action)',color:'var(--action-text)',border:'0'};
  return <button onClick={disabled?undefined:onClick} disabled={disabled} style={{...v,minHeight:48,padding:'0 22px',borderRadius:'var(--radius-button)',fontFamily:'var(--font-ui)',fontSize:17,fontWeight:600,cursor:disabled?'default':'pointer',width:full?'100%':'auto'}}>{children}</button>;
}