زر أساسي أو ثانوي أو مقفل بارتفاع 48 واستدارة 14.

```jsx
<Button>ابدأ رحلتك</Button>
<Button variant="secondary">ثانوي</Button>
<Button disabled>مقفل</Button>
```