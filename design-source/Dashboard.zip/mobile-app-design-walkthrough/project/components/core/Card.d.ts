export interface CardProps{variant?:'border'|'shadow'|'tint';pad?:number;onClick?:()=>void;children?:React.ReactNode}
export function Card(props:CardProps):JSX.Element;