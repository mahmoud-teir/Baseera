import React from 'react';
export function Card({children,variant='border',onClick,pad=16}){
  const s=variant==='shadow'?{border:'1px solid transparent',boxShadow:'var(--shadow-card)',background:'var(--surface-card)'}:variant==='tint'?{border:'1px solid transparent',background:'var(--bs-green-soft)'}:{border:'1px solid var(--border)',background:'var(--surface-card)'};
  return <div onClick={onClick} style={{...s,borderRadius:'var(--radius-card)',padding:pad,color:'var(--text-body)',cursor:onClick?'pointer':'default'}}>{children}</div>;
}