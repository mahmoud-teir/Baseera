بطاقة بثلاثة أنماط: حدود أو ظل أو مظلّلة.

```jsx
<Card variant="shadow">محتوى</Card>
```