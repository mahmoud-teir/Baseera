export interface ChipProps{label:string;active?:boolean;tone?:'green'|'gold';onClick?:()=>void}
export function Chip(props:ChipProps):JSX.Element;