import React from 'react';
export function Chip({label,active=false,tone='green',onClick}){
  const bg=active?'var(--action)':tone==='gold'?'var(--bs-gold-soft)':'var(--bs-green-soft)';
  const fg=active?'var(--action-text)':tone==='gold'?'var(--bs-gold-ink)':'var(--bs-green)';
  return <button onClick={onClick} style={{border:0,background:bg,color:fg,borderRadius:'var(--radius-pill)',minHeight:44,padding:'0 16px',fontFamily:'var(--font-ui)',fontSize:15,fontWeight:600,cursor:'pointer'}}>{label}</button>;
}