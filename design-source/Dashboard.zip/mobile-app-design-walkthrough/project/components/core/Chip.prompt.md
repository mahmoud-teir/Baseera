شريحة حالة أو فلتر.

```jsx
<Chip label="مكتمل" />
<Chip label="قيد الدراسة" tone="gold" />
<Chip label="الكل" active />
```