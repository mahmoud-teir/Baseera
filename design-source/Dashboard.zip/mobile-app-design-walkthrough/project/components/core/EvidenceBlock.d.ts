export interface EvidenceBlockProps{label:string;text?:string|null;source?:string;reference?:string}
export function EvidenceBlock(props:EvidenceBlockProps):JSX.Element;