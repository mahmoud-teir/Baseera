import React from 'react';
export function EvidenceBlock({label,text,source,reference}){
  if(!text) return <div style={{border:'1.5px dashed var(--accent)',borderRadius:12,padding:10,fontSize:14,color:'var(--accent-text)',lineHeight:1.7,fontFamily:'var(--font-ui)'}}>موضع {label}: يُدرج النص من مصدر موثّق مع رقمه وتخريجه.</div>;
  return <div style={{background:'var(--surface-card)',borderRadius:14,padding:12,display:'flex',flexDirection:'column',gap:6,fontFamily:'var(--font-ui)'}}><span style={{fontSize:13,fontWeight:600,color:'var(--accent-text)'}}>{label}</span><span style={{fontFamily:'var(--font-display)',fontSize:20,lineHeight:2}}>{text}</span><span style={{fontSize:13,color:'var(--text-muted)'}}>{source} · {reference}</span></div>;
}