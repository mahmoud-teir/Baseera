export interface LessonRowProps{code:string;title:string;state?:'done'|'current'|'locked';onClick?:()=>void}
export function LessonRow(props:LessonRowProps):JSX.Element;