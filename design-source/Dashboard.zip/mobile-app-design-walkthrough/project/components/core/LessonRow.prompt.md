صف درس بثلاث حالات: مكتمل، حالي، مقفل.

```jsx
<LessonRow code="AQ-01" title="لماذا نتعلم العقيدة؟" state="current" />
```