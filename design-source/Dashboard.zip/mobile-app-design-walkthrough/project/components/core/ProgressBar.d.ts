export interface ProgressBarProps{value?:number;light?:boolean}
export function ProgressBar(props:ProgressBarProps):JSX.Element;