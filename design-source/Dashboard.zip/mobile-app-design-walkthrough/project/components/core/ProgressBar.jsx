import React from 'react';
export function ProgressBar({value=0,light=false}){
  return <div style={{height:6,borderRadius:9,background:light?'rgba(255,255,255,.2)':'var(--border)'}}><div style={{width:Math.max(0,Math.min(100,value))+'%',height:6,borderRadius:9,background:light?'var(--accent)':'var(--action)'}}/></div>;
}