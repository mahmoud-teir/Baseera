شريط تقدّم من 0 إلى 100. light للخلفيات الخضراء.

```jsx
<ProgressBar value={40} />
```