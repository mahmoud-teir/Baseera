# Lesson data schema (lessons.json)

One object per lesson. The Lesson and Quiz screens render purely from this data — no layout work per lesson.

```
{
  "code": "AQ-01",                 // subject prefix + number
  "title": "…",
  "minutes": 15,
  "audioTime": "02:10 / 07:00",    // until real audio is wired
  "objectives": ["…", "…"],        // any count
  "sections": [{ "heading": "…", "body": "…" }],   // any count
  "evidence": [{
    "kind": "quran | hadith | ref",
    "label": "آية | حديث | مرجع علمي",
    "text": null,                  // null → dashed "pending" slot; string → verified card
    "source": "…", "ref": "…"      // shown under verified text
  }],
  "wajh": "…", "explain": "…", "level": 1, "reviewers": ["…"], "reviewedAt": "…"   // اختياري على كل دليل أو قسم، يملأ بطاقة «اعرف الدليل» (level: 1 مجمع عليه · 2 قول الجمهور · 3 خلاف معتبر · 4 اجتهاد لم يُعتمد)
  "summary": ["…"],
  "quiz": {
    "passPct": 85,
    "questions": [{ "q": "…", "options": ["…","…","…","…"], "answer": 1, "explain": "…" }]  // any count
  }
}
```

Rules: no evidence `text` without a verified source and reference. Question count is free (progress bar, scoring and pass threshold adapt).
