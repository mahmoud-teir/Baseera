const {Button,Chip,ProgressBar,Card,LessonRow,EvidenceBlock}=BS;
const TITLES=['لماذا نتعلم العقيدة؟','عنوان الدرس الثاني (تجريبي)','عنوان الدرس الثالث (تجريبي)','عنوان الدرس الرابع (تجريبي)'];
const SUBJECTS=[['العقيدة والتوحيد',4],['الفقه والعبادات',11],['القرآن والتفسير',8],['الحديث النبوي',8]];
const Ico=({d,c='currentColor',s=22})=><svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><path d={d}/></svg>;
const TABS=[['home','الرئيسية','M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z'],['academy','الأكاديمية','M22 10 12 5 2 10l10 5 10-5z M6 12v5c3 2 9 2 12 0v-5'],['quran','القرآن','M2 4h6a4 4 0 0 1 4 4v13a3 3 0 0 0-3-3H2z M22 4h-6a4 4 0 0 0-4 4v13a3 3 0 0 1 3-3h7z']];
function TabBar({tab,go}){return <div style={{height:84,flex:'none',background:'var(--surface-card)',borderTop:'1px solid var(--border)',display:'flex',justifyContent:'space-around',paddingTop:10,boxSizing:'border-box'}}>{TABS.map(([k,l,d])=>{const on=tab===k;return <button key={k} onClick={()=>go(k)} style={{border:0,background:'none',color:on?'var(--bs-green)':'var(--text-muted)',fontSize:13,fontWeight:600,display:'flex',flexDirection:'column',alignItems:'center',gap:5,width:72,cursor:'pointer'}}><span style={{width:44,height:28,borderRadius:14,background:on?'var(--bs-green-soft)':'transparent',display:'flex',alignItems:'center',justifyContent:'center'}}><Ico d={d} c={on?'var(--bs-green)':'var(--text-muted)'}/></span>{l}</button>})}</div>;}
function Home({go,done}){return <div style={{flex:1,overflowY:'auto',padding:'52px 20px 20px',display:'flex',flexDirection:'column',gap:18}}>
  <div><div style={{fontSize:15,color:'var(--text-muted)'}}>السلام عليكم ورحمة الله</div><div style={{fontFamily:'var(--font-display)',fontSize:28,fontWeight:700,lineHeight:1.4}}>أهلًا بك يا طالب العلم</div></div>
  <div style={{background:'var(--bs-green)',color:'#fff',borderRadius:24,padding:18,display:'flex',flexDirection:'column',gap:12}}>
    <div style={{fontSize:14,color:'var(--bs-gold)',fontWeight:600}}><span dir="ltr">AQ-0{done+1}</span> · العقيدة والتوحيد</div><div style={{fontSize:21,fontWeight:600}}>{TITLES[done]}</div>
    <ProgressBar light value={done/4*100}/><div style={{display:'flex',justifyContent:'flex-end'}}><button onClick={()=>go('lesson')} style={{background:'var(--bs-ivory)',color:'var(--bs-green)',border:0,borderRadius:12,minHeight:44,padding:'0 18px',fontSize:16,fontWeight:700,cursor:'pointer'}}>تابع الدرس</button></div></div>
  <div style={{display:'flex',gap:8}}><Chip label="مكتمل"/><Chip label="قيد الدراسة" tone="gold"/></div>
  <Card variant="shadow" onClick={()=>go('academy')}><div style={{fontWeight:700,fontSize:19}}>الأكاديمية الإسلامية</div><div style={{fontSize:14,color:'var(--text-muted)',marginTop:4}}>المرحلة الأولى · 6 مواد</div></Card></div>;}
function Academy({go,done}){return <div style={{flex:1,overflowY:'auto',padding:'52px 20px 20px',display:'flex',flexDirection:'column',gap:12}}>
  <div style={{fontFamily:'var(--font-display)',fontSize:30,fontWeight:700}}>الأكاديمية الإسلامية</div>
  {SUBJECTS.map(([n,c],i)=><Card key={n} onClick={i===0?()=>go('subject'):undefined}><div style={{display:'flex',justifyContent:'space-between',fontWeight:600,fontSize:17}}><span>{n}</span><span style={{fontSize:14,color:'var(--bs-green)'}}>{i===0?Math.round(done/4*100):0}%</span></div><div style={{margin:'10px 0 6px'}}><ProgressBar value={i===0?done/4*100:0}/></div><div style={{fontSize:14,color:'var(--text-muted)'}}>{c} دروس</div></Card>)}</div>;}
function Subject({go,done}){return <div style={{flex:1,overflowY:'auto',padding:'52px 20px 20px',display:'flex',flexDirection:'column',gap:8}}>
  <button onClick={()=>go('academy')} style={{alignSelf:'flex-start',border:0,background:'none',color:'var(--bs-green)',fontSize:15,fontWeight:600,minHeight:44,cursor:'pointer',padding:0}}>‹ الأكاديمية</button>
  <div style={{fontFamily:'var(--font-display)',fontSize:30,fontWeight:700,marginBottom:6}}>العقيدة والتوحيد</div>
  {TITLES.map((t,i)=><LessonRow key={t} code={'AQ-0'+(i+1)} title={t} state={i<done?'done':i===done?'current':'locked'} onClick={()=>go('lesson')}/>)}</div>;}
function Lesson({go,finish,done}){return <div style={{flex:1,overflowY:'auto',padding:'52px 20px 20px',display:'flex',flexDirection:'column',gap:14}}>
  <button onClick={()=>go('subject')} style={{alignSelf:'flex-start',border:0,background:'none',color:'var(--bs-green)',fontSize:15,fontWeight:600,minHeight:44,cursor:'pointer',padding:0}}>‹ العقيدة والتوحيد</button>
  <div style={{fontFamily:'var(--font-display)',fontSize:30,fontWeight:700,lineHeight:1.4}}>{TITLES[Math.min(done,3)]}</div>
  <div style={{fontSize:17,lineHeight:2.1,color:'var(--text-body)'}}>نص تجريبي للشرح: يُكتب هنا محتوى الدرس بعبارات واضحة للمبتدئين.</div>
  <EvidenceBlock label="آية"/><EvidenceBlock label="حديث"/>
  <Button full onClick={finish}>أنهيت الدرس · اجتياز الاختبار</Button></div>;}
function App(){const [scr,setScr]=React.useState('home'),[done,setDone]=React.useState(0);
  const tab=scr==='home'?'home':'academy';
  const go=k=>setScr(k==='quran'?'academy':k);
  const finish=()=>{setDone(d=>Math.min(4,d+1));setScr('subject')};
  const body=scr==='home'?<Home go={go} done={done}/>:scr==='academy'?<Academy go={go} done={done}/>:scr==='subject'?<Subject go={go} done={done}/>:<Lesson go={go} finish={finish} done={done}/>;
  return <div style={{width:390,height:844,borderRadius:40,background:'var(--bg)',color:'var(--text-body)',boxShadow:'0 20px 50px rgba(24,45,41,.3)',overflow:'hidden',display:'flex',flexDirection:'column',position:'relative'}}>{body}<TabBar tab={tab} go={go}/></div>;}
ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
